fetch("https://api.myjson.com/bins/z4mag")
.then(function(response) {
return response.json();
})
.then(function(data) {
app.Teams= data;
app.Teams2= data;
app.AllData= data;
filtrarDrop(data);

app3.Maps= data;  
dropLocations(data);
app3.cambiarMapa(app3.data, app3.mapaElegido)
})
.catch(err=>console.log())
//-----fetch----------------------------------------fetch------------------------------------//

/*SINGLE PAGE APLICATION*/
const app2 = {
  pages: [],
  show: new Event('show'),
  init: function(){
      app2.pages = document.querySelectorAll('.page');
      app2.pages.forEach((pg)=>{
          pg.addEventListener('show', app2.pageShown);
      })
      
      document.querySelectorAll('.nav-link').forEach((link)=>{
          link.addEventListener('click', app2.nav);
      })
      history.replaceState({}, 'Home', '#home');
      window.addEventListener('popstate', app2.poppin);
  },
  nav: function(ev){
      ev.preventDefault();
      let currentPage = ev.target.getAttribute('data-target');
      document.querySelector('.active').classList.remove('active');
      document.getElementById(currentPage).classList.add('active');
      console.log(currentPage)
      history.pushState({}, currentPage, `#${currentPage}`);
      document.getElementById(currentPage).dispatchEvent(app2.show);
  },
  pageShown: function(ev){
      console.log('Page', ev.target.id, 'just shown');
      let h1 = ev.target.querySelector('h1');
      h1.classList.add('big')
      setTimeout((h)=>{
          h.classList.remove('big');
      }, 1200, h1);
  },
  poppin: function(ev){
      console.log(location.hash, 'popstate event');
      let hash = location.hash.replace('#' ,'');
      document.querySelector('.active').classList.remove('active');
      document.getElementById(hash).classList.add('active');
      console.log(hash)
      //history.pushState({}, currentPage, `#${currentPage}`);
      document.getElementById(hash).dispatchEvent(app2.show);
  }
}

document.addEventListener('DOMContentLoaded', app2.init);

/* CALCULO FUNCIONES  */
var app = new Vue({  
    el: '#app',  
    data: {
      Teams: [],
      Teams2: [],
      AllData: [],
      SelectValue: "all",
      checkedBox: [],

   },
   methods: {
          filtro(){
             
            this.Teams = this.AllData.filter(match => match.Day == this.SelectValue || this.SelectValue == "all");  
         },
         FiltrarTeams() {
          this.Teams2 =  FiltrarTeams(this.checkedBox, this.AllData)
             }
        } 
     });
var app3 = new Vue({
      el: "#app3",
      data: {
        Maps: [],
        Maps2: [],
        mapaElegido: "Select a location",
      },
      methods: {
     
        cambiarMapa() {
          this.Maps2 =  cambiarMapa(this.Maps, this.mapaElegido)
        }
      }
    });

  function filtrarDrop(AllDays){
    let tabla = [];
    for (var i = 0; i<AllDays.length; i++){
      //value states
      if(!tabla.includes(`<option value="${AllDays[i].Day}">${AllDays[i].Day}</option>`)){
        tabla.push(`<option value="${AllDays[i].Day}">${AllDays[i].Day}</option>`);

      }
    }
    tabla.unshift(`<option value="all">All Days</option>`)
    document.getElementById("mySelecty").insertAdjacentHTML("beforeend", tabla);
  }
   /*Filtros Teams*/
   function FiltrarTeams(checkedBox, data) {
    let AllTeam =[];
        for(var i= 0; i< data.length; i++){
          var TeamsJust = data[i].Teams.split(' ');
            if(checkedBox.length == false){
             AllTeam.push(data[i]) 
                   }
          for (var j= 0; j< checkedBox.length; j++) {     
            if (TeamsJust.indexOf(checkedBox[j]) > -1 ){
                AllTeam.push(data[i]);
              }
            }
          }

        return AllTeam;
        }
        
      //LOCATINES FILTROS

        function dropLocations(data){
          let tabla = [];
          for (var i = 0; i<data.length; i++){
            //value states
            if(!tabla.includes(`<option value="${data[i].Location}">${data[i].Location}</option>`)){
              tabla.push(`<option value="${data[i].Location}">${data[i].Location}</option>`);
            }
          }
          
          document.getElementById("selector").insertAdjacentHTML("beforeend", tabla);
        }
        
        function cambiarMapa(data, mapaElegido){
          let direcciones = [];
          for(var i=0; i<data.length; i++){
            if(data[i][mapaElegido] ){
              direcciones.push((data[i][mapaElegido]));
              break;
        
            }else if(mapaElegido.length == 17){ direcciones.push(data[1].Greenbay) }
        
          }
         return direcciones;
        }